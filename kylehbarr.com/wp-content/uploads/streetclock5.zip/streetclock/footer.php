
<div style="clear: both;">&nbsp;</div>
</div>
</div>
<!-- end page -->
<div id="footer-bgcontent">
<div id="footer">
	<p class="legal">&copy;2008
		<?php bloginfo('name'); ?>
		&nbsp;&nbsp;&bull;&nbsp;&nbsp; <a href="<?php bloginfo('rss2_url'); ?>">Entries (RSS)</a> &nbsp;&nbsp;&bull;&nbsp;&nbsp; <a href="<?php bloginfo('comments_rss2_url'); ?>">Comments (RSS)</a> &nbsp;&nbsp;&bull;&nbsp;&nbsp;
		
		Powered by <a href="http://wordpress.org/">WordPress</a>.
		&nbsp;&nbsp;&bull;&nbsp;&nbsp;
		Designed by <a href="http://www.freewpthemes.net/">Free WordPress Themes</a>. </p>
</div>
</div>
<?php wp_footer(); ?>
</body></html>