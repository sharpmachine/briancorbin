<div id="footer">
	<div class="copy">Copyright &copy; 2007 - <?php bloginfo('name'); ?> - is proudly powered by <a href="http://www.wordpress.org">WordPress</a><br /><a href="http://www.infocreek.com">Website Design</a> by InfoCreek | <a href="http://www.infocreek.com/webdesign/aspire.html">Aspire Theme</a> | <a href="http://websitetemplates.ritecounter.com/">Website Templates</a>
	<div class="valid">Valid <a href="http://validator.w3.org/check?uri=referer">XHTML</a> &amp; <a href="http://jigsaw.w3.org/css-validator/validator?uri=<?php bloginfo('stylesheet_url'); ?>">CSS</a></div></div>
</div>
<?php wp_footer(); ?>
</body>
</html>
