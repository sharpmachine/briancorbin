<?php get_header(); ?>

<div id="content">
	<div id="main">
		<div class="content"><div class="cont-r"><div class="cont-l"><div class="cont-bot">
			<div class="grad-hack"><div class="begin"></div>
				<div class="post1">
					<div class="entry">
						<h2 class="center">Error 404 - Not Found</h2>
					</div>
				</div>
			</div>
		</div></div></div></div>
	</div>
	<?php get_sidebar(); ?>
	<div class="clear"></div>
</div>

<?php get_footer(); ?>
