

</div>
<hr />
<div id="footer">

	<div class="footerwrap">
    <div class="copyright">
		<?php bloginfo('name'); ?> is designed by
		<a href="http://www.productivedreams.com/">productivedreams</a> for <a href="http://www.smashingmagazine.com">Smashing Magazine</a>
	</div>
    <div class="primarynav">	<?php wp_list_pages('title_li=<h2>Pages</h2>' ); ?>
    </div>
</div>

<?php ?>

		<?php wp_footer(); ?>
</body>
</html>
