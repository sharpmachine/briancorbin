<div class="footer">
&#169; Copyright <?php bloginfo('name'); ?>  &middot;  All rights reserved  &middot;  Proudly powered by <a href="http://wordpress.org">WordPress</a>  &middot;  <a href="http://fivebyfive.com.ar/wp-themes/spotless">Spotless</a> theme by <a href="http://taly.com.ar/blog">Taly</a>
</div>
<?php wp_footer(); ?>  

<!-- "Spotless" design by Taly - http://taly.com.ar/blog/ -->   
<!-- Also visit "http://fivebyfive.com.ar/wp-themes" for other photoblog themes -->  


</div>
</body>  
</html>