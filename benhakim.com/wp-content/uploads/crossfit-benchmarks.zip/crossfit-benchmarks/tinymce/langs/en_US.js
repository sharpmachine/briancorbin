tinyMCE.addI18n({en_US:{
cetsHelloWorld:{	
desc : 'Insert an RSS Feed'
}}});