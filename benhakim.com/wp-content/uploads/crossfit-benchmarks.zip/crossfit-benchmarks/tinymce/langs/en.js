tinyMCE.addI18n({en:{
cetsHelloWorld:{	
desc : 'Insert an RSS Feed'
}}});
